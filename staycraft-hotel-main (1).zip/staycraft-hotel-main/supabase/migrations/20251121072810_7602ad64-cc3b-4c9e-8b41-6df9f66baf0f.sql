-- Create rooms table
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_number TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'booked')),
  description TEXT,
  image_url TEXT,
  capacity INTEGER NOT NULL DEFAULT 2,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create bookings table
CREATE TABLE public.bookings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  check_in_date DATE NOT NULL,
  check_out_date DATE NOT NULL,
  total_price DECIMAL(10, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'cancelled', 'completed')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for rooms (public read)
CREATE POLICY "Anyone can view available rooms"
  ON public.rooms
  FOR SELECT
  USING (true);

-- RLS Policies for bookings (users can only see their own bookings)
CREATE POLICY "Users can view their own bookings"
  ON public.bookings
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bookings"
  ON public.bookings
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings"
  ON public.bookings
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_bookings_user_id ON public.bookings(user_id);
CREATE INDEX idx_bookings_room_id ON public.bookings(room_id);
CREATE INDEX idx_bookings_dates ON public.bookings(check_in_date, check_out_date);

-- Insert sample rooms data
INSERT INTO public.rooms (room_number, type, price, description, capacity, status) VALUES
  ('101', 'Standard Room', 99.99, 'Cozy single room with basic amenities', 1, 'available'),
  ('102', 'Standard Room', 99.99, 'Comfortable single room', 1, 'available'),
  ('201', 'Deluxe Room', 149.99, 'Spacious double room with city view', 2, 'available'),
  ('202', 'Deluxe Room', 149.99, 'Elegant double room with modern decor', 2, 'available'),
  ('301', 'Suite', 249.99, 'Luxury suite with living area and premium amenities', 4, 'available'),
  ('302', 'Suite', 249.99, 'Executive suite with panoramic views', 4, 'available'),
  ('401', 'Presidential Suite', 499.99, 'Ultimate luxury experience with VIP services', 6, 'available');
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { Hotel, CalendarIcon, Users, DollarSign, ArrowLeft } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface Room {
  id: string;
  room_number: string;
  type: string;
  price: number;
  description: string;
  capacity: number;
  status: string;
}

const Rooms = () => {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [checkInDate, setCheckInDate] = useState<Date>();
  const [checkOutDate, setCheckOutDate] = useState<Date>();
  const [bookingLoading, setBookingLoading] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
    };
    checkAuth();

    fetchRooms();
  }, []);

  const fetchRooms = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("rooms")
      .select("*")
      .eq("status", "available")
      .order("price", { ascending: true });

    if (error) {
      toast.error("Failed to load rooms");
    } else {
      setRooms(data || []);
    }
    setLoading(false);
  };

  const handleBookRoom = async (room: Room) => {
    if (!user) {
      toast.error("Please login to book a room");
      navigate("/auth");
      return;
    }

    if (!checkInDate || !checkOutDate) {
      toast.error("Please select check-in and check-out dates");
      return;
    }

    if (checkInDate >= checkOutDate) {
      toast.error("Check-out date must be after check-in date");
      return;
    }

    setBookingLoading(true);

    const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
    const totalPrice = room.price * nights;

    const { error } = await supabase.from("bookings").insert({
      user_id: user.id,
      room_id: room.id,
      check_in_date: format(checkInDate, "yyyy-MM-dd"),
      check_out_date: format(checkOutDate, "yyyy-MM-dd"),
      total_price: totalPrice,
    });

    if (error) {
      toast.error("Failed to create booking");
    } else {
      toast.success("Booking confirmed!");
      setSelectedRoom(null);
      setCheckInDate(undefined);
      setCheckOutDate(undefined);
      navigate("/my-bookings");
    }

    setBookingLoading(false);
  };

  const calculateTotal = () => {
    if (!checkInDate || !checkOutDate || !selectedRoom) return 0;
    const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
    return selectedRoom.price * nights;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Hotel className="w-8 h-8 text-primary" />
            <h1 className="text-2xl font-bold text-foreground">Available Rooms</h1>
          </div>
          {user ? (
            <Button onClick={() => navigate("/dashboard")}>Dashboard</Button>
          ) : (
            <Button onClick={() => navigate("/auth")}>Login</Button>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="text-center py-12">Loading rooms...</div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {rooms.map((room) => (
              <Card key={room.id} className="hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{room.type}</span>
                    <span className="text-sm font-normal text-muted-foreground">
                      #{room.room_number}
                    </span>
                  </CardTitle>
                  <CardDescription>{room.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span>{room.capacity} guests</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-accent" />
                      <span className="font-bold text-lg">${room.price}</span>
                      <span className="text-muted-foreground">/night</span>
                    </div>
                  </div>

                  {selectedRoom?.id === room.id ? (
                    <div className="space-y-3 pt-4 border-t">
                      <div className="grid grid-cols-2 gap-2">
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className={cn("justify-start text-left font-normal", !checkInDate && "text-muted-foreground")}>
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {checkInDate ? format(checkInDate, "PPP") : "Check-in"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={checkInDate}
                              onSelect={setCheckInDate}
                              disabled={(date) => date < new Date()}
                              initialFocus
                              className="pointer-events-auto"
                            />
                          </PopoverContent>
                        </Popover>

                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className={cn("justify-start text-left font-normal", !checkOutDate && "text-muted-foreground")}>
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {checkOutDate ? format(checkOutDate, "PPP") : "Check-out"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={checkOutDate}
                              onSelect={setCheckOutDate}
                              disabled={(date) => date <= (checkInDate || new Date())}
                              initialFocus
                              className="pointer-events-auto"
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      {checkInDate && checkOutDate && (
                        <div className="text-center p-3 bg-muted rounded-lg">
                          <p className="text-sm text-muted-foreground">Total</p>
                          <p className="text-2xl font-bold text-primary">${calculateTotal()}</p>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" onClick={() => setSelectedRoom(null)}>
                          Cancel
                        </Button>
                        <Button onClick={() => handleBookRoom(room)} disabled={bookingLoading || !checkInDate || !checkOutDate}>
                          {bookingLoading ? "Booking..." : "Confirm"}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button className="w-full" onClick={() => setSelectedRoom(room)}>
                      Book Now
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Rooms;
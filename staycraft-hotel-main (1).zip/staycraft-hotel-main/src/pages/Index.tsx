import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Hotel, BedDouble, Shield, Clock } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-accent/20 text-primary-foreground">
        <div className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-accent rounded-full flex items-center justify-center shadow-2xl">
                <Hotel className="w-12 h-12 text-accent-foreground" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
              Welcome to Elite Hotel Management
            </h1>
            <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-2xl mx-auto">
              Experience luxury and comfort with our premium rooms and exceptional service
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button
                size="lg"
                onClick={() => navigate("/rooms")}
                className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8"
              >
                Browse Rooms
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => navigate("/auth")}
                className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-lg px-8"
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Why Choose Us</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the perfect blend of luxury, comfort, and technology
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            <div className="bg-card p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <BedDouble className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-3 text-card-foreground">Luxury Rooms</h3>
              <p className="text-muted-foreground">
                Premium accommodations with modern amenities and elegant design for your ultimate comfort
              </p>
            </div>
            <div className="bg-card p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-3 text-card-foreground">Secure Booking</h3>
              <p className="text-muted-foreground">
                Safe and secure reservation system with instant confirmation and flexible cancellation
              </p>
            </div>
            <div className="bg-card p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <Clock className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold mb-3 text-card-foreground">24/7 Service</h3>
              <p className="text-muted-foreground">
                Round-the-clock customer support and services to ensure your stay is perfect
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Book Your Stay?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-primary-foreground/90">
            Join thousands of satisfied guests and experience hospitality redefined
          </p>
          <Button
            size="lg"
            onClick={() => navigate("/auth")}
            className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8"
          >
            Get Started Today
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Index;

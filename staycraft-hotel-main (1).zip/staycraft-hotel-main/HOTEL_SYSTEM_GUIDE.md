# Hotel Management System - Complete Guide

## 🏨 Project Overview
A complete, production-ready Hotel Management System built with React, TypeScript, and Lovable Cloud (PostgreSQL database).

## ✨ Features Implemented

### 1. **Authentication System**
- Secure signup with email and password
- Login with session management
- Password hashing automatically handled
- Auto-confirm email enabled for development

### 2. **Database Schema**
Three main tables:

#### **users** (via Lovable Cloud Auth)
- Managed automatically by the authentication system
- Stores: id, email, password_hash, user_metadata

#### **rooms**
- id (UUID, primary key)
- room_number (unique)
- type (Standard Room, Deluxe Room, Suite, Presidential Suite)
- price (decimal)
- status (available/booked)
- description
- capacity (number of guests)
- created_at

#### **bookings**
- id (UUID, primary key)
- user_id (references auth.users)
- room_id (references rooms)
- check_in_date
- check_out_date
- total_price
- status (confirmed/cancelled/completed)
- created_at

### 3. **Pages**
- **Home** (`/`) - Landing page with hero section
- **Auth** (`/auth`) - Login/Signup page
- **Dashboard** (`/dashboard`) - User dashboard with stats
- **Rooms** (`/rooms`) - Browse and book available rooms
- **My Bookings** (`/my-bookings`) - View and manage bookings

### 4. **Security (Row Level Security)**
- Rooms: Public read access
- Bookings: Users can only see/manage their own bookings
- All data properly protected with RLS policies

## 🚀 How to Use

### Testing the Application

1. **Sign Up**
   - Go to `/auth`
   - Fill in: Full Name, Email, Password
   - Click "Sign Up"
   - You'll be automatically logged in (email confirmation disabled for development)

2. **Browse Rooms**
   - Click "Browse Rooms" from home or dashboard
   - View available rooms with prices and details

3. **Book a Room**
   - Click "Book Now" on any room
   - Select check-in and check-out dates
   - See total price calculated automatically
   - Click "Confirm" to complete booking

4. **View Bookings**
   - Go to "My Bookings" from dashboard
   - See all your reservations
   - Cancel bookings if needed

### Sample Rooms Available
The database is pre-populated with 7 rooms:
- **Standard Rooms** (101, 102) - $99.99/night
- **Deluxe Rooms** (201, 202) - $149.99/night
- **Suites** (301, 302) - $249.99/night
- **Presidential Suite** (401) - $499.99/night

## 🗄️ Database Access

### View Database Tables
Access your database through Lovable Cloud:
1. Click the "Cloud" tab in Lovable
2. Navigate to "Database" → "Tables"
3. View/edit: users, rooms, bookings

### Run SQL Queries
You can run custom queries in the database section to:
- View all bookings
- Check room availability
- Update room prices
- Generate reports

Example queries:
```sql
-- View all bookings with user and room details
SELECT 
  b.*,
  r.room_number,
  r.type,
  u.email
FROM bookings b
JOIN rooms r ON b.room_id = r.id
JOIN auth.users u ON b.user_id = u.id
ORDER BY b.created_at DESC;

-- Check room availability
SELECT * FROM rooms WHERE status = 'available';

-- View revenue by room type
SELECT 
  r.type,
  COUNT(b.id) as bookings_count,
  SUM(b.total_price) as total_revenue
FROM bookings b
JOIN rooms r ON b.room_id = r.id
WHERE b.status = 'confirmed'
GROUP BY r.type;
```

## 🎨 Design System

### Color Palette
- **Primary**: Deep teal (#1A7F7F) - Trust, professionalism
- **Accent**: Gold (#F5A623) - Luxury, hospitality
- **Background**: Clean white/light gray
- **Semantic tokens used throughout** - No hardcoded colors

### Components
All UI components from shadcn/ui:
- Forms with validation
- Date pickers for booking
- Cards for room/booking display
- Toasts for notifications

## 🔐 Security Features

1. **Authentication**
   - Secure password hashing
   - Session management with JWT
   - Protected routes

2. **Row Level Security (RLS)**
   - Users can only access their own bookings
   - All database operations validated server-side

3. **Input Validation**
   - Date validation (check-out after check-in)
   - Price calculations server-side
   - SQL injection prevention

## 📊 Admin Functions

To view all data (admin perspective), use the Cloud database viewer:

### View All Users
```sql
SELECT id, email, created_at FROM auth.users;
```

### View All Bookings
```sql
SELECT * FROM bookings ORDER BY created_at DESC;
```

### View All Rooms
```sql
SELECT * FROM rooms ORDER BY room_number;
```

### Update Room Status
```sql
UPDATE rooms SET status = 'available' WHERE id = 'room-id';
```

### Add New Room
```sql
INSERT INTO rooms (room_number, type, price, description, capacity, status)
VALUES ('501', 'Penthouse Suite', 799.99, 'Ultimate luxury penthouse', 8, 'available');
```

## 🔧 Technical Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS with custom design tokens
- **UI Components**: shadcn/ui
- **Backend**: Lovable Cloud (Supabase/PostgreSQL)
- **Authentication**: Supabase Auth
- **Forms**: React Hook Form
- **Date Handling**: date-fns
- **Routing**: React Router v6

## 📈 Future Enhancements

Possible additions:
- Room images
- Payment integration (Stripe)
- Email notifications
- Reviews and ratings
- Admin dashboard
- Advanced search filters
- Calendar availability view
- Multiple room booking
- Guest profiles with preferences

## 🐛 Troubleshooting

### Can't see bookings after creating them?
- Check RLS policies are enabled
- Ensure you're logged in
- Verify user_id matches in bookings table

### Room not showing as available?
- Check room status in database
- Verify RLS policy on rooms table

### Login not working?
- Verify email and password
- Check auth is configured correctly
- Ensure auto-confirm is enabled

## 📝 Project Structure

```
src/
├── pages/
│   ├── Index.tsx          # Home page
│   ├── Auth.tsx           # Login/Signup
│   ├── Dashboard.tsx      # User dashboard
│   ├── Rooms.tsx          # Browse & book rooms
│   ├── MyBookings.tsx     # View bookings
│   └── NotFound.tsx       # 404 page
├── components/
│   └── ui/                # shadcn components
├── integrations/
│   └── supabase/          # Auto-generated
├── index.css              # Design system
└── App.tsx                # Routes

Database Schema (Lovable Cloud):
- auth.users (managed by auth system)
- public.rooms
- public.bookings
```

## ✅ Deliverables Checklist

- ✅ Clean, modern UI
- ✅ Home, Login, Signup, Dashboard, Rooms, Bookings pages
- ✅ Functional authentication (signup/login)
- ✅ PostgreSQL database with proper schema
- ✅ users table (via auth system)
- ✅ rooms table with sample data
- ✅ bookings table with relationships
- ✅ Row Level Security policies
- ✅ Secure password hashing
- ✅ Session management
- ✅ Room browsing and filtering
- ✅ Date-based booking system
- ✅ Price calculation
- ✅ Booking management
- ✅ Responsive design
- ✅ Database access through Cloud UI
- ✅ Complete documentation

---

**Your hotel management system is ready to use! 🎉**

Start by signing up at `/auth` and exploring the features.